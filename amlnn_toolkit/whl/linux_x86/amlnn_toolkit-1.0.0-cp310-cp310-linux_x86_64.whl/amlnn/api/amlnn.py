#
#    Copyright (c) 2022 amlogic Corporation
#
#    Permission is hereby granted, free of charge, to any person obtaining a
#    copy of this software and associated documentation files (the "Software"),
#    to deal in the Software without restriction, including without limitation
#    the rights to use, copy, modify, merge, publish, distribute, sublicense,
#    and/or sell copies of the Software, and to permit persons to whom the
#    Software is furnished to do so, subject to the following conditions:
#
#    The above copyright notice and this permission notice shall be included in
#    all copies or substantial portions of the Software.
#
#    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
#    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
#    DEALINGS IN THE SOFTWARE.

from amlnn.api.amlnn_base import AMLNN_Base
from amlnn.api.amlnn_llm_base import AMLNN_LLM_Base

class AMLNN:
    def __init__(self,log_level: str ='INFO'):
        self.base = AMLNN_Base(log_level=log_level)

    def load_onnx(self, model: str =None, inputs:list[str]=None, input_shapes:list[list]=None, outputs:list[str]=None):
        '''
        load_onnx: load original model
        args:
            model: onnx model path
            inputs: model input nodes. Default:None. only need to set it when you need to specify input nodes and shapes.['input1','input2']
            input_shapes: shape corresponding to the input node.Default:None. single input: [1,3,223,224] or multi-input: [[1,3,224,224],[x,x,x,x]]
            outputs: model output node. Default:None. only need to set it when onnx need to be truncated.
        return:
            success: 0, failure: -1
        '''
        ret = self.base.load_onnx(model=model, inputs=inputs, input_shapes=input_shapes, outputs=outputs)
        return ret

    def load_pytorch(self, model: str =None, inputs:list[str]=None, input_shapes:list[list]=None, dtypes:list[str]=None):
        '''
        load_pytorch: load original model
        args:
            model: pt model path (The pt model saved after using jit.trace)
            inputs: model input nodes. Default:None. only need to set it when you need to specify input nodes and shapes.['input1','input2']
            input_shapes: shape corresponding to the input node.Default:None. example of single input: [1,3,223,224] or multi-inputs: [[1,3,223,224],[x,x,x,x]]
            dtypes: dtype corresponding to the input node. Default:None, mean float32. example of multi-inputs: ['float32','float32','int32']
        return:
            success: 0, failure: -1
        '''
        ret = self.base.load_pytorch(model=model, inputs=inputs, input_shapes=input_shapes, dtypes=dtypes)
        return ret

    def load_tflite(self, model: str=None, quantized_model: bool=False ):
        '''
        load_tflite: load original model
        args:
            model: tflite model path
            quantized_model: Specify whether it is a quantized TFLite model. Default: False. This is only effective when quantized_dtype is w4a8 or w8a8.
        return:
            success: 0, failure: -1
        '''
        ret = self.base.load_tflite(model=model,quantized_model=quantized_model)
        return ret

    def load_pt2(self, model: str =None, outputs:list[str]=None):
        '''
        load_pt2: load original model
        args:
            model: pt2 model path (The pytorch model saved using torch.export.save)
            outputs: model output node. Default:None. only need to set it when pt2 need to be truncated.
        return:
            success: 0, failure: -1
        '''
        ret = self.base.load_pt2(model=model, outputs=outputs)
        return ret

    def config(self,normalization_mean:[list[float]]=None, normalization_std:[list[float]]=None, \
                    quantized_dtype : str ='w8a8', activation_dtype: str ='f16', \
                    quantized_method: str='perchannel', group_size: int =32, \
                    activation_quant_algo: str='normal', weight_quant_algo: str ='normal', \
                    histogram_bins: int = 2048, omse_range: float= 90, omse_steps: float = 0.02,\
                    percentile_sigma:float = 0.01, percentile_alpha:float = 0.99999, \
                    hybrid_ratio: float=0.5, apply_smooth_o3: bool =False, \
                    inference_input_type:str = 'quant', inference_output_type: str = 'quant', \
                    export_intermediate: bool=False, output_dir: str =None, \
                    target_platform: str ='PRODUCT_PID0XA003'):
        '''
        config: Configure conversion related parameters
        args:
            1.Input preprocessing:
                normalization_mean: The average value of each channel. The default value is 0 when set to None.
                normalization_std: Standard deviation of each channel. The default value is 1 when set to None.

            2.Quantization basic settings:
                quantized_dtype : Default: 'w8a8'. currently support ['w8a8','w4a8','w4a16','w8a16','w16a16']
                activation_dtype: Specify the type of activation. Default:f16.support['f16','bf16']

            3.Advanced quantization configuration:
                quantized_method: Specify the quantization methods for conv/fc operators, support[perlayer/perchannel]
                group_size: Specify the group size for pergroup. This only applies when quantized_dtype ='w4a16'. Default:32, support [32/64/128/256]
                activation_quant_algo: Specify model feature quantization algo.Default:normal(min-max).support ['normal', 'histogram', 'percentile', 'omse']
                weight_quant_algo: Specify model wegihts quantization algo.Default:normal(min-max).support ['normal', 'lsq','decoupleQ']
                hybrid_ratio:0.5, This only applies when quantized-dtype:'w4a8','w4a16'.

            4.Smooth quantization options:
                apply_smooth_o3:  Specify whether to use the smooth algorithm. Default:False.

            5.Output control:
                inference_input_type:  support ['float32', 'int8','uint8','int16']
                inference_output_type: support ['float32', 'int8','uint8','int16']
                export_intermediate: Specify whether to export the intermediate tflite during the conversion process.Default:False.
                output_dir: The output path. Default: None, The default output for None is:  model_name + "_adla_unify"

            6.Specify platform
                target_platform: specify platform type, support ['PRODUCT_PID0XA001','PRODUCT_PID0XA002','PRODUCT_PID0XA003','PRODUCT_PID0XA004','PRODUCT_PID0XA005','PRODUCT_PID0XA006','PRODUCT_PID0XA007','PRODUCT_PID0XA008']
        return:
            success: 0, failure: -1
        '''
        ret = self.base.config(normalization_mean=normalization_mean, normalization_std=normalization_std, quantized_dtype=quantized_dtype , activation_dtype=activation_dtype, \
                                quantized_method=quantized_method, group_size=group_size, activation_quant_algo=activation_quant_algo, \
                                weight_quant_algo=weight_quant_algo, histogram_bins=histogram_bins,omse_range=omse_range,omse_steps=omse_steps, \
                                percentile_sigma=percentile_sigma, percentile_alpha=percentile_alpha, inference_input_type = inference_input_type, \
                                inference_output_type = inference_output_type, hybrid_ratio=hybrid_ratio, apply_smooth_o3=apply_smooth_o3, export_intermediate=export_intermediate, \
                                target_platform=target_platform,output_dir=output_dir)
        return ret

    def compile(self, dataset:str =None, iterations: int =-1):
        '''
        compile: Transform and quantize model.
        args:
            dataset: The path of the quantization dataset.
            iterations: Quantization iterations number.Default:-1, mean use all datasets in the dataset.
        return:
            success: 0, failure: -1
        '''
        ret = self.base.compile(dataset=dataset, iterations=iterations)

    def export_adla(self):
        '''
        export_adla: Export adla file.
        return:
            success: 0, failure: -1
        '''
        ret = self.base.export_adla()
        return ret

    def export_encrypted_model(self):
        pass

    def codegen(self):
        '''
        function: Export template code.
        return:
            success: 0, failure: -1
        '''
        ret = self.base.codegen()
        return ret

    def adla_memory_evaluate(self,adla_path: str =None):
        """
        memory model
        adla_path: adla file path
        """
        self.base.adla_memory_evaluate(adla_path)

    def init_runtime(self, mode="nnserver", board_work_path="/data/nn", enable_perf=False):
        '''
        init_runtime: initialize runtime environment
        args:
            mode: runtime mode, supports nnserver, native or simulator(TODO)
            board_work_path: working directory used on target board
            enable_perf: whether to enable performance profiling
        return:
            success: 0, failure: -1
        '''
        return self.base.init_runtime(mode=mode, board_work_path=board_work_path, enable_perf=enable_perf)

    def get_sdk_version(self):
        '''
        get_sdk_version: get sdk version information
        args:
            none
        return:
            sdk version string
        '''
        return self.base.get_sdk_version()

    def load_model(self, path):
        '''
        load_model: load model
        args:
            path: local model file path, adla file or tflite file path for runtime.
        return:
            model input and output tensor information
        '''
        return self.base.load_model(path=path)

    def get_tensor_info(self):
        '''
        get_tensor_info: get cached model tensor information
        args:
            none
        return:
            model input and output tensor information
        '''
        return self.base.get_tensor_info()

    def inference(self, inputs, inputs_data_format="NHWC", outputs_data_format="NHWC", run_cycles=1):
        '''
        inference: run model inference
        args:
            inputs: input tensor data, accepts one numpy array or a list or tuple of numpy arrays
            inputs_data_format: input tensor layout, supports NHWC or NCHW
            outputs_data_format: output tensor layout, supports NHWC or NCHW
            run_cycles: number of inference cycles to execute
        return:
            output tensor list
        '''
        return self.base.inference(inputs=inputs, inputs_data_format=inputs_data_format, outputs_data_format=outputs_data_format, run_cycles=run_cycles)

    def get_perf_info(self):
        '''
        get_perf_info: get performance profiling information
        args:
            none
        return:
            formatted performance information string
        '''
        return self.base.get_perf_info()

    def perf_visualize(self):
        '''
        perf_visualize: generate performance visualization reports
        args:
            none
        return:
            none
        '''
        self.base.perf_visualize()

    def uninit(self):
        '''
        function: Release resources and initialize state.
        return:
            success: 0, failure: -1
        '''
        ret = self.base.uninit()
        return ret

class  AMLNN_LLM:
    def __init__(self,log_level='INFO'):
        self.base = AMLNN_LLM_Base(log_level=log_level)

    def load_gguf(self, model):
        """
        model_path: gguf model path
        return: success: 0, failure: -1
        """
        ret = self.base.load_gguf(model)
        return ret

    def load_model():
        #LLM onnx onnx model  --> onnx2tf -->ai_quantizer --> tflite_refactor -->multi-subgraph.
        #tflite float --> ai_quantizer --> tflite_refactor -->multi-subgraph.
        pass

    def config(self, prefill_batch_length:int=32, max_context: int=2048, transformer_model_type: str='LLM', target_platform: str='PRODUCT_PID0XA007', output_dir: str=None):
        '''
        config: Configure conversion related parameters
        args:
            1.Output control:
                prefill_batch_length:Control the maximum number of tokens processed at one time in a single prefill phase.
                max_context: The max context value, Recommended setting value [256,512,1024,2048]. Default: 2048
                transformer_model_type:Valid values: ['MMPROJ', 'LLM', 'VLM']. Default value: LLM.
                output_dir: The output path. Default: None, The default output for None is:  model_name + "_adla_unify"

            2.Specify platform
                target_platform: specify platform type , support ['PRODUCT_PID0XA001','PRODUCT_PID0XA002','PRODUCT_PID0XA003','PRODUCT_PID0XA004','PRODUCT_PID0XA005']
        return:
            success: 0, failure: -1
        '''
        ret = self.base.config(prefill_batch_length=prefill_batch_length, max_context=max_context, transformer_model_type=transformer_model_type, target_platform=target_platform, output_dir=output_dir)
        return ret

    def compile(self):
        """
        compile: Transform and quantize model.
        return:
            success: 0, failure: -1
        """
        ret = self.base.compile()

        return ret

    # def codegen(self):
    #     '''
    #     function: Export template code.
    #     return:
    #         success: 0, failure: -1
    #     '''
    #     ret = self.base.codegen()
    #     return ret

    def adla_memory_evaluate(self, adla_path: str = None):
        """
        memory model
        adla_path: adla file path
        """
        self.base.adla_memory_evaluate(adla_path)

    def uninit(self):
        '''
        function: Release resources and initialize state.
        return:
            success: 0, failure: -1
        '''
        ret = self.base.uninit()
        return ret