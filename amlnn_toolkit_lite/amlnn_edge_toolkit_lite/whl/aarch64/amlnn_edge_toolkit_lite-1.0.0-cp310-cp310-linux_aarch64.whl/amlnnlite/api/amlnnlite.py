#
#    Copyright (c) 2022 amlogic Corporation
#
#    Permission is hereby granted, free of charge, to any person obtaining a
#    copy of this software and associated documentation files (the "Software"),
#    to deal in the Software without restriction, including without limitation
#    the rights to use, copy, modify, merge, publish, distribute, sublicense,
#    and/or sell copies of the Software, and to permit persons to whom the
#    Software is furnished to do so, subject to the following conditions:
#
#    The above copyright notice and this permission notice shall be included in
#    all copies or substantial portions of the Software.
#
#    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
#    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
#    DEALINGS IN THE SOFTWARE.

from amlnnlite.api.amlnnlite_inference_base import AMLNNLiteInferenceBase


class AMLNNLite:
    def __init__(self, log_level="ERROR"):
        '''
        __init__: create an AMLNNLite instance
        args:
            log_level: python-side log level used by the AMLNNLite runtime
        return:
            none
        '''
        self._base = AMLNNLiteInferenceBase(log_level=log_level)

    def init_runtime(self, mode="native", board_work_path="/data/nn", enable_perf=False):
        '''
        init_runtime: initialize runtime environment
        args:
            mode: runtime mode, only supports native in AMLNNLite
            board_work_path: working directory used on target board
            enable_perf: whether to enable performance profiling
        return:
            success: 0, failure: -1
        '''
        return self._base.init_runtime(mode=mode, board_work_path=board_work_path, enable_perf=enable_perf)

    def get_sdk_version(self):
        '''
        get_sdk_version: get sdk version information
        args:
            none
        return:
            sdk version string
        '''
        return self._base.get_sdk_version()

    def load_model(self, path):
        '''
        load_model: load model
        args:
            path: local model file path
        return:
            model input and output tensor information
        '''
        return self._base.load_model(path=path)

    def get_tensor_info(self):
        '''
        get_tensor_info: get cached model tensor information
        args:
            none
        return:
            model input and output tensor information
        '''
        return self._base.get_tensor_info()

    def inference(self, inputs, inputs_data_format="NHWC", outputs_data_format="NHWC", run_cycles=1):
        '''
        inference: run model inference
        args:
            inputs: input tensor data, accepts one numpy array or a list or tuple of numpy arrays
            inputs_data_format: input tensor layout, supports NHWC or NCHW
            outputs_data_format: output tensor layout, supports NHWC or NCHW
            run_cycles: number of inference cycles to execute
        return:
            output tensor list
        '''
        return self._base.inference(inputs=inputs, inputs_data_format=inputs_data_format, outputs_data_format=outputs_data_format, run_cycles=run_cycles)

    def get_perf_info(self):
        '''
        get_perf_info: get performance profiling information
        args:
            none
        return:
            formatted performance information string
        '''
        return self._base.get_perf_info()

    def perf_visualize(self):
        '''
        perf_visualize: generate performance visualization reports
        args:
            none
        return:
            none
        '''
        self._base.perf_visualize()

    def uninit(self):
        '''
        uninit: release runtime and model resources
        args:
            none
        return:
            none
        '''
        self._base.uninit()
