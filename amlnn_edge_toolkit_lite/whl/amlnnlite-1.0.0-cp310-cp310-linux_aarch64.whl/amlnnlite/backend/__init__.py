# -*- coding: utf-8 -*-
"""
ARM backend loader
"""

try:
    from .native import ArmLiteBackend  # type: ignore
except Exception as exc:
    raise ImportError(
        "Failed to load AMLNNLite ARM backend extension. "
        "Please rebuild via src_amlnnlite_arm/build-python.sh."
    ) from exc

__all__ = ["ArmLiteBackend"]
