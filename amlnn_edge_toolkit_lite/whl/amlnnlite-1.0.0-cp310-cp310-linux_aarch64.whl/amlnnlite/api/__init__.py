# -*- coding: utf-8 -*-
"""
AMLNNLite API Module
只导出编译后的.so文件，不包含源码
"""

import importlib.util
import os
import glob
import sys

def _find_so_modules():
    """查找所有的.so模块文件"""
    current_dir = os.path.dirname(__file__)
    
    # 查找所有.so文件
    so_files = glob.glob(os.path.join(current_dir, "*.cpython-*-*.so"))
    
    modules = {}
    for so_file in so_files:
        basename = os.path.basename(so_file)
        # 从文件名提取模块名：server.cpython-310-x86_64-linux-gnu.so -> server
        module_name = basename.split('.')[0]
        modules[module_name] = so_file
    
    return modules

def _load_all_modules():
    """加载所有必要的模块，确保依赖关系正确"""
    modules = _find_so_modules()
    
    if not modules:
        raise ImportError("No compiled modules (.so files) found")
    
    # 按依赖顺序加载：先加载被依赖的模块
    load_order = ['visual_script', 'server_log', 'server']
    loaded_modules = {}
    
    for module_name in load_order:
        if module_name in modules:
            so_path = modules[module_name]
            try:
                # 使用简单的模块名，避免命名空间问题
                spec = importlib.util.spec_from_file_location(module_name, so_path)
                module = importlib.util.module_from_spec(spec)
                
                # 注册到sys.modules，确保其他模块能找到
                sys.modules[module_name] = module
                sys.modules[f"amlnnlite.api.{module_name}"] = module
                sys.modules[f"amlnnlite.{module_name}"] = module
                
                spec.loader.exec_module(module)
                loaded_modules[module_name] = module
                
            except Exception as e:
                raise ImportError(f"Failed to load {module_name} from {so_path}: {e}")
    
    return loaded_modules

# 尝试加载所有模块并导出AMLNNLite类
try:
    modules = _load_all_modules()
    
    # 从server模块获取AMLNNLite类
    if 'server' in modules:
        AMLNNLite = modules['server'].AMLNNLite
        __all__ = ['AMLNNLite']
    else:
        raise ImportError("Server module not found")
        
except ImportError as e:
    print(f"Warning: Failed to load AMLNNLite: {e}")
    print("Make sure the package is properly built with Cython.")
    
    # 定义一个占位符类，避免导入错误
    class AMLNNLite:
        def __init__(self):
            raise RuntimeError("AMLNNLite not properly built. Run src_amlnnlite_arm/build-python.sh first.")
    
    __all__ = ['AMLNNLite']
