# -*- coding: utf-8 -*-
"""
AMLNNLite Package
Amlogic Deep Learning Accelerator Neural Network Lite Interface
"""

# 运行时读取版本信息（直接读取仓库根目录）
# 构建阶段通过脚本替换
__version__ = "1.0.0"
__version_date__ = "2025.12"
__version_string__ = f"AMLNNLite, v{__version__}, {__version_date__}"
__author__ = "AMLNN Team"

# 不在__init__.py中导出AMLNNLite，遵循标准包结构
# 用户应该使用: from amlnnlite.api import AMLNNLite
__all__ = []
